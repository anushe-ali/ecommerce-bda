from numpy._core.defchararray import *
from numpy._core.defchararray import __all__, __doc__
