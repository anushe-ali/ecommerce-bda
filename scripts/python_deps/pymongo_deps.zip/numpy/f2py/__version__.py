from numpy.version import version  # noqa: F401
